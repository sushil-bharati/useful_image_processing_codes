% This creates a text file to assis you in tabulating table in the latex for the Precision rates and Success
% Rates of each dataset for each tracker
% Requirements: All the OPEs and Ground Truth should be in the same folder
% OPE files should follow the format : datasetName_OPE_trackerName.txt
% Ground truth should follow the format: dasetName.txt
% Output file created is : latex_parse_ver1.txt
%precision OPE


m1=[];s1=[];cl=[];
for i = 1:7
    %read gt files
gt1 = fopen('airplane_001.txt','r');
gt2 = fopen('airplane_004.txt','r');
gt3 = fopen('airplane_005.txt','r');
gt4 = fopen('airplane_006.txt','r');
gt5 = fopen('airplane_007.txt','r');
gt6 = fopen('airplane_011.txt','r');
gt7 = fopen('airplane_012.txt','r');
gt8 = fopen('airplane_013.txt','r');
gt9 = fopen('airplane_015.txt','r');
gt10 = fopen('airplane_016.txt','r');
gt11 = fopen('big_2.txt','r');
gt12 = fopen('planestv_1.txt','r');
gt13 = fopen('planestv_2.txt','r');
gt14 = fopen('planestv_3.txt','r');
gt15 = fopen('planestv_4.txt','r');
gt16 = fopen('planestv_5.txt','r');
gt17 = fopen('planestv_6.txt','r');
gt18 = fopen('planestv_7.txt','r');
gt19 = fopen('planestv_8.txt','r');
gt20 = fopen('planestv_9.txt','r');
gt21 = fopen('youtube_1.txt','r');
gt22 = fopen('youtube_2.txt','r');
gt23 = fopen('youtube_3.txt','r');
gt24 = fopen('dog.txt','r');
gt25 = fopen('Skater.txt','r');
    
    %select tracker
    if (i==1) tracker = 'ours.txt'; end
    if (i==2) tracker = 'CN.txt'; end
    if (i==3) tracker = 'CT.txt'; end
    if (i==4) tracker = 'DSST.txt'; end
    if (i==5) tracker = 'KCF.txt'; end
    if (i==6) tracker = 'SAMF.txt'; end
    if (i==7) tracker = 'STC.txt'; end
    
    %read all the OPEs
    str1 = strcat('airplane_001_OPE_',tracker);    fileid1 = fopen(str1,'r'); 
    str2 = strcat('airplane_004_OPE_',tracker);    fileid2 = fopen (str2,'r'); 
    str3 = strcat('airplane_005_OPE_',tracker);    fileid3 = fopen(str3,'r');
    str4 = strcat('airplane_006_OPE_',tracker);    fileid4 = fopen (str4,'r');
    str5 = strcat('airplane_007_OPE_',tracker);    fileid5 = fopen(str5,'r'); 
    str6 = strcat('airplane_011_OPE_',tracker);    fileid6 = fopen (str6,'r'); 
    str7 = strcat('airplane_012_OPE_',tracker);    fileid7 = fopen(str7,'r');
    str8 = strcat('airplane_013_OPE_',tracker);    fileid8 = fopen (str8,'r');
    str9 = strcat('airplane_015_OPE_',tracker);   fileid9 = fopen(str9,'r');
    str10 = strcat('airplane_016_OPE_',tracker);   fileid10 = fopen (str10,'r');
    str11 = strcat('big_2_OPE_',tracker);          fileid11 = fopen(str11,'r');
    str12 = strcat('planestv_1_OPE_',tracker);          fileid12 = fopen(str12,'r');
    str13 = strcat('planestv_2_OPE_',tracker);          fileid13 = fopen(str13,'r');
    str14 = strcat('planestv_3_OPE_',tracker);          fileid14 = fopen(str14,'r');
    str15 = strcat('planestv_4_OPE_',tracker);          fileid15 = fopen(str15,'r');
    str16 = strcat('planestv_5_OPE_',tracker);          fileid16 = fopen(str16,'r');
    str17 = strcat('planestv_6_OPE_',tracker);          fileid17 = fopen(str17,'r');
    str18 = strcat('planestv_7_OPE_',tracker);          fileid18 = fopen(str18,'r');
    str19 = strcat('planestv_8_OPE_',tracker);          fileid19 = fopen(str19,'r');
    str20 = strcat('planestv_9_OPE_',tracker);          fileid20 = fopen(str20,'r');
    str21 = strcat('youtube_1_OPE_',tracker);          fileid21 = fopen(str21,'r');
    str22 = strcat('youtube_2_OPE_',tracker);          fileid22 = fopen(str22,'r');
    str23 = strcat('youtube_3_OPE_',tracker);          fileid23 = fopen(str23,'r');
    str24 = strcat('Dog_OPE_',tracker);    fileid24 = fopen (str24,'r');
    str25 = strcat('Skater_OPE_',tracker);    fileid25 = fopen(str25,'r');
    
    %initiating average precision, success rate and cle
    pr =[]; sr=[]; cle = []; 
    
    %for each dataset, proceed now sequentially
    for j = 1 : 25
        file = strcat ('fileid',num2str(j));
        file = eval(file);
        tline1 = fgetl(file);
        gtfile = strcat ('gt',num2str(j));
        gtfile = eval(gtfile);
        tline2 = fgetl(gtfile);
       C=[];D=[];
       A=[];B=[];
        while (ischar(tline2))
    C1 = textscan (tline1,'%f,%f,%f,%f');
    C2 = textscan (tline2,'%f,%f,%f,%f');
    
    %Scale adjustment for SAMF
    if i == 6
       % C1{1} =  C1{1}/2;
        %C1{2} = C1{2}/2;
        C1{3} = C1{3}*2;
        C1{4} = C1{4}*2;
    end
        
    %M1 = double (C1{1}) + ((double(C1{3}) - double(C1{1}))/2.0);
    %N1 = double (C1{2}) + ((double(C1{4}) - double(C1{2}))/2.0);
    M1 =  double (C1{1}) + (double(C1{3})/2.0) ; %if output is in x,y,w,h format
    N1 =  double (C1{2}) + ( double(C1{4})/2.0);
    %M2 = double (C2{1}) + ((double(C2{3}) - double(C2{1}))/2.0);
    %N2 = double (C2{2}) + ((double(C2{4}) - double(C2{2}))/2.0);
    M2 = double (C2{1}) + (double(C2{3})/2.0) ; %if gt is in x,y,w,h format
    N2 = double (C2{2}) + (double(C2{4})/2.0);
    
    %for SR
     %w1 = double(C1{3}) - double(C1{1});
   % h1 = double(C1{4}) - double(C1{2});
     w1 =  double(C1{3}); % if output in x,y,w,h format
    h1 =  double(C1{4});
    %w2 = double(C2{3}) - double(C2{1});
    %h2 = double(C2{4}) - double(C2{2});
    w2 = double(C2{3}); % if ground truth in x,y,w,h format
    h2 = double(C2{4});
    
    X1 = [C1{1} C1{2} w1 h1];
    X2 = [C2{1} C2{2} w2 h2];
  
    
    C = vertcat (C,X1);  
    D = vertcat (D,X2);
    
    Z1 = [M1 N1];
    Z2 = [M2 N2];
    
    A = vertcat (A,Z1);  
    B = vertcat (B,Z2);
    tline1 = fgetl(file);
    tline2 = fgetl(gtfile);
        end
    
    
   [p,~,c]=precision_plots(A,B,0); %calculate precision
   [s,~] = success_plots(C,D); %calculate SR
    pr = [pr, p]; %since we need to keepaccount of 50 points in each dataset
    sr  = [sr, s];
    cle = [cle,c];
   
    end
   m1 = [m1; mean(pr)];
   s1 = [s1;mean(sr)];
   cl = [cl;mean(cle)];
   fclose('all');close('all');
end
m1 = round(m1,2); s1 = round(s1,2); 
  handle1 = fopen('latex_parse_ver1.txt','w+');
 %Printing the results to a file
  fprintf(handle1, 'ORDER: %10s %10s %10s %10s %10s %10s %10s\n','Ours','CN','CT','DSST','STC','SAMF','KCF');
 fprintf(handle1,'Precision Table\n');
  seq = {'airplane\_001';'airplane\_004';'airplane\_005';'airplane\_006';'airplane\_007';'airplane\_011';'airplane\_012'; ...
      'airplane\_013'; 'airplane\_015';'airplane\_016';'big\_2';'planestv\_1';'planestv\_2';'planestv\_3';'planestv\_4';'planestv\_5';'planestv\_6';...
      'planestv\_7';'planestv\_8';'planestv\_9';'youtube\_1';'youtube\_2';'youtube\_3';'Dog';'Skater'};

   
       for jj = 1:25
           fprintf(handle1,'\\hline\n');
       fprintf(handle1,'%s&%.2f&%.2f&%.2f&%.2f&%.2f&%.2f&%.2f\\\\\n',char(seq(jj)),m1(1,jj),m1(2,jj),m1(3,jj),m1(4,jj),m1(6,jj),m1(7,jj),m1(5,jj));
       end
      
        
 fprintf(handle1,'\n\nSuccess Rate Table\n'); 
     
       for jj = 1:25
           fprintf(handle1,'\\hline\n');
       fprintf(handle1,'%s&%.2f&%.2f&%.2f&%.2f&%.2f&%.2f&%.2f\\\\\n',char(seq(jj)),s1(1,jj),s1(2,jj),s1(3,jj),s1(4,jj),s1(6,jj),s1(7,jj),s1(5,jj));
       end

    fprintf(handle1,'\n\nCLE\n + %.2f',mean(mean(cl)));
   fclose('all');
    
    
    
